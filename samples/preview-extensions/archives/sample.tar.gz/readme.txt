Inside the sample archive.
